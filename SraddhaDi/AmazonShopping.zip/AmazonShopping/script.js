alert("I tried my best to achieve AMAZON app ")

function openSlideMenu(){
document.getElementById("side-menu").style.width="250px";             
          
}

function closeSlideMenu(){
          document.getElementById("side-menu").style.width="0px";}
          